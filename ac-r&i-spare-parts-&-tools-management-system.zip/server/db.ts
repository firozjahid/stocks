import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  User,
  InventoryItem,
  ItemRequest,
  MovementTransaction,
  AuditLog,
  NotificationItem,
  DatabaseBackup,
  SystemLocation,
  SystemTeam
} from '../src/types/inventory.js';
import {
  INITIAL_USERS,
  INITIAL_ITEMS,
  INITIAL_REQUESTS,
  INITIAL_TRANSACTIONS,
  INITIAL_AUDIT_LOGS,
  INITIAL_LOCATIONS,
  INITIAL_TEAMS
} from './seedData.js';
import { importSparePartsFromExcel } from './excelSync.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const BACKUPS_DIR = path.resolve(DATA_DIR, 'backups');
const DB_FILE = path.resolve(DATA_DIR, 'database.json');
const BACKUP_INDEX_FILE = path.resolve(BACKUPS_DIR, 'backups_meta.json');

export interface DatabaseState {
  version: number;
  lastUpdated: string;
  users: User[];
  items: InventoryItem[];
  requests: ItemRequest[];
  transactions: MovementTransaction[];
  auditLogs: AuditLog[];
  notifications: NotificationItem[];
  locations: SystemLocation[];
  teams: SystemTeam[];
  systemSettings: {
    systemName: string;
    organization: string;
    autoBackupIntervalMinutes: number;
    lastSuccessfulBackup?: string;
    lastBackupAttempt?: string;
    backupStatus: 'HEALTHY' | 'WARNING' | 'ERROR';
    backupErrorDetails?: string;
    allowTechnicianRequests: boolean;
  };
}

class DatabaseManager {
  private state: DatabaseState | null = null;
  private isWriting = false;
  private backupTimer: NodeJS.Timeout | null = null;

  constructor() {
    this.ensureDirectories();
    this.loadState();
    this.startAutoBackupSchedule();
  }

  private ensureDirectories() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(BACKUPS_DIR)) {
      fs.mkdirSync(BACKUPS_DIR, { recursive: true });
    }
  }

  private getDefaultState(): DatabaseState {
    const excelItems = importSparePartsFromExcel();
    return {
      version: 1,
      lastUpdated: new Date().toISOString(),
      users: JSON.parse(JSON.stringify(INITIAL_USERS)),
      items: excelItems.length > 0 ? excelItems : JSON.parse(JSON.stringify(INITIAL_ITEMS)),
      requests: JSON.parse(JSON.stringify(INITIAL_REQUESTS)),
      transactions: JSON.parse(JSON.stringify(INITIAL_TRANSACTIONS)),
      auditLogs: JSON.parse(JSON.stringify(INITIAL_AUDIT_LOGS)),
      notifications: [],
      locations: JSON.parse(JSON.stringify(INITIAL_LOCATIONS)),
      teams: JSON.parse(JSON.stringify(INITIAL_TEAMS)),
      systemSettings: {
        systemName: 'R.A.C R&I Store Center',
        organization: 'Walton Hi-Tech Industries PLC.',
        autoBackupIntervalMinutes: 5,
        lastSuccessfulBackup: new Date().toISOString(),
        lastBackupAttempt: new Date().toISOString(),
        backupStatus: 'HEALTHY',
        allowTechnicianRequests: true,
      }
    };
  }

  private loadState() {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        this.state = JSON.parse(raw);
        // Enforce the master employee database from Excel file
        if (this.state && INITIAL_USERS && INITIAL_USERS.length > 0) {
          this.state.users = JSON.parse(JSON.stringify(INITIAL_USERS));
        }
        if (this.state) {
          // Clear any legacy dummy items, requests, and transactions
          this.state.items = (this.state.items || []).filter(item => !item.id.startsWith('ITEM-SP-00') && !item.id.startsWith('ITEM-TL-00'));
          this.state.requests = (this.state.requests || []).filter(r => !r.id.startsWith('REQ-20260922') && !r.id.startsWith('REQ-20260920') && !r.id.startsWith('REQ-20260928'));
          this.state.transactions = (this.state.transactions || []).filter(t => !t.id.startsWith('BRW-20260922') && !t.id.startsWith('BRW-20260920'));
          this.state.notifications = (this.state.notifications || []).filter(n => !n.id.startsWith('NOTIF-INIT-'));

          // If items is empty, auto-import from Spare Parts.xlsx
          if (this.state.items.length === 0) {
            const excelItems = importSparePartsFromExcel();
            if (excelItems.length > 0) {
              this.state.items = excelItems;
              console.log(`[DB] Auto-synchronized ${excelItems.length} real spare parts from Spare Parts.xlsx`);
            }
          }

          if (this.state.systemSettings) {
            this.state.systemSettings.systemName = 'R.A.C R&I Store Center';
            this.state.systemSettings.organization = 'Walton Hi-Tech Industries PLC.';
          }

          this.persistSync();
          console.log(`[DB] Persistent database loaded with ${this.state.users.length} master employees and ${this.state.items.length} items.`);
        }
      } else {
        console.log('[DB] Initializing new database with master seed data...');
        this.state = this.getDefaultState();
        this.persistSync();
        // Create initial backup
        this.createBackup('SYSTEM INITIALIZATION', 'Initial master seed backup');
      }
    } catch (err) {
      console.error('[DB] Error loading database file. Initializing default fallback:', err);
      this.state = this.getDefaultState();
      this.persistSync();
    }
  }

  private persistSync() {
    if (!this.state) return;
    this.state.lastUpdated = new Date().toISOString();
    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    const payload = JSON.stringify(this.state, null, 2);
    fs.writeFileSync(tempFile, payload, 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  }

  public async persist(): Promise<void> {
    if (this.isWriting) {
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    this.isWriting = true;
    try {
      this.persistSync();
    } finally {
      this.isWriting = false;
    }
  }

  public getState(): DatabaseState {
    if (!this.state) {
      this.loadState();
    }
    return this.state!;
  }

  public clearAllDummyData(clearedBy: string, employeeId: string) {
    const state = this.getState();
    state.items = [];
    state.requests = [];
    state.transactions = [];
    state.notifications = [];
    state.auditLogs = [];
    this.persistSync();
    this.logAudit({
      user: clearedBy,
      employeeId: employeeId,
      action: 'UPDATE',
      module: 'SYSTEM',
      details: 'Master inventory cleared. All dummy items, requests, and transactions removed.',
    });
    this.persistSync();
  }

  public syncFromExcel(syncedBy: string, employeeId: string): { count: number; message: string } {
    const excelItems = importSparePartsFromExcel();
    if (excelItems.length === 0) {
      return { count: 0, message: 'No items could be read from Spare Parts.xlsx' };
    }

    const state = this.getState();
    // Preserve custom user-added items created through UI
    const userAddedItems = (state.items || []).filter(item => !item.id.startsWith('ITEM-SP-EXCEL-'));

    state.items = [...excelItems, ...userAddedItems];
    this.persistSync();

    this.logAudit({
      user: syncedBy,
      employeeId: employeeId,
      action: 'IMPORT',
      module: 'SPARE_PARTS',
      details: `Synchronized ${excelItems.length} spare parts directly from Spare Parts.xlsx into authorized officer panels.`,
    });
    this.persistSync();
    return { count: excelItems.length, message: `Successfully synchronized ${excelItems.length} spare parts from Spare Parts.xlsx.` };
  }

  // --- AUDIT LOGGING ---
  public logAudit(entry: Omit<AuditLog, 'id' | 'timestamp'>): AuditLog {
    const log: AuditLog = {
      ...entry,
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };
    const state = this.getState();
    state.auditLogs.unshift(log);
    // Keep last 5000 logs in active memory
    if (state.auditLogs.length > 5000) {
      state.auditLogs.pop();
    }
    this.persist();
    return log;
  }

  // --- NOTIFICATIONS ---
  public addNotification(userId: string, title: string, message: string, type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ALERT' = 'INFO', linkUrl?: string) {
    const notif: NotificationItem = {
      id: `NOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      title,
      message,
      type,
      linkUrl,
      read: false,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };
    this.getState().notifications.unshift(notif);
    this.persist();
  }

  // --- AUTOMATED BACKUP SCHEDULER (EVERY 5 MINUTES) ---
  private startAutoBackupSchedule() {
    const INTERVAL_MS = 5 * 60 * 1000; // 5 minutes
    this.backupTimer = setInterval(() => {
      try {
        console.log('[BACKUP] Running scheduled 5-minute automated snapshot...');
        this.createBackup('SYSTEM (AUTOMATED 5-MIN)', 'Automatic 5-minute database backup snapshot');
      } catch (err: any) {
        console.error('[BACKUP] Automated backup execution error:', err);
        const state = this.getState();
        state.systemSettings.backupStatus = 'ERROR';
        state.systemSettings.backupErrorDetails = err?.message || 'Unknown backup failure';
        state.systemSettings.lastBackupAttempt = new Date().toISOString();
        this.persist();
      }
    }, INTERVAL_MS);
  }

  public createBackup(createdBy: string = 'SUPER ADMIN', description: string = 'Manual database backup'): DatabaseBackup {
    const state = this.getState();
    const timestamp = new Date();
    const dateStr = timestamp.toISOString().split('T')[0];
    const timeStr = timestamp.toTimeString().split(' ')[0];
    const backupId = `BKP-${dateStr.replace(/-/g, '')}-${timestamp.getTime()}`;
    const filename = `${backupId}.json`;
    const targetPath = path.resolve(BACKUPS_DIR, filename);

    try {
      state.systemSettings.lastBackupAttempt = timestamp.toISOString();
      const payload = JSON.stringify(state, null, 2);
      fs.writeFileSync(targetPath, payload, 'utf-8');
      const stats = fs.statSync(targetPath);

      const backupRecord: DatabaseBackup = {
        id: backupId,
        date: dateStr,
        time: timeStr,
        sizeBytes: stats.size,
        createdBy,
        status: 'SUCCESS',
        filename,
        description,
        recordCounts: {
          users: state.users.length,
          items: state.items.filter(i => !i.isDeleted).length,
          requests: state.requests.length,
          transactions: state.transactions.length,
          auditLogs: state.auditLogs.length,
        }
      };

      // Update backup metadata index
      const backups = this.getBackups();
      backups.unshift(backupRecord);
      
      // Retention policy: Keep the last 100 backup snapshots
      if (backups.length > 100) {
        const toPrune = backups.slice(100);
        for (const old of toPrune) {
          try {
            const oldPath = path.resolve(BACKUPS_DIR, old.filename);
            if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
          } catch (e) {
            console.error('Failed to prune old backup:', e);
          }
        }
        backups.splice(100);
      }

      fs.writeFileSync(BACKUP_INDEX_FILE, JSON.stringify(backups, null, 2), 'utf-8');

      state.systemSettings.lastSuccessfulBackup = timestamp.toISOString();
      state.systemSettings.backupStatus = 'HEALTHY';
      state.systemSettings.backupErrorDetails = undefined;
      this.persist();

      this.logAudit({
        user: createdBy,
        employeeId: 'SYS',
        action: 'BACKUP',
        module: 'SYSTEM',
        details: `Database snapshot created: ${backupId} (${(stats.size / 1024).toFixed(1)} KB).`,
      });

      return backupRecord;
    } catch (err: any) {
      state.systemSettings.backupStatus = 'ERROR';
      state.systemSettings.backupErrorDetails = err?.message || 'Snapshot write failed';
      this.persist();
      throw err;
    }
  }

  public getBackups(): DatabaseBackup[] {
    try {
      if (fs.existsSync(BACKUP_INDEX_FILE)) {
        return JSON.parse(fs.readFileSync(BACKUP_INDEX_FILE, 'utf-8'));
      }
    } catch (e) {
      console.error('Error reading backup index:', e);
    }
    return [];
  }

  public getBackupFilePath(filename: string): string | null {
    const filePath = path.resolve(BACKUPS_DIR, filename);
    if (fs.existsSync(filePath)) {
      return filePath;
    }
    return null;
  }

  // --- RESTORE WITH SAFETY SNAPSHOT FIRST ---
  public restoreBackup(backupId: string, performedBy: string, performedByEmpId: string): { success: boolean; safetyBackupId: string } {
    const backups = this.getBackups();
    const targetMeta = backups.find(b => b.id === backupId);
    if (!targetMeta) {
      throw new Error(`Backup snapshot ${backupId} not found in catalog.`);
    }

    const targetFile = path.resolve(BACKUPS_DIR, targetMeta.filename);
    if (!fs.existsSync(targetFile)) {
      throw new Error(`Backup snapshot file ${targetMeta.filename} is missing on disk.`);
    }

    // MANDATORY REQUIREMENT: Safety snapshot of current database before restoring!
    const safetySnapshot = this.createBackup(
      `SAFETY PRE-RESTORE (${performedBy})`,
      `Safety backup created automatically before restoring snapshot ${backupId}`
    );

    const raw = fs.readFileSync(targetFile, 'utf-8');
    const restoredState: DatabaseState = JSON.parse(raw);

    // Verify minimum structural integrity
    if (!restoredState.users || !restoredState.items) {
      throw new Error('Corrupted or incompatible database snapshot structure.');
    }

    this.state = restoredState;
    this.persistSync();

    this.logAudit({
      user: performedBy,
      employeeId: performedByEmpId,
      action: 'RESTORE',
      module: 'SYSTEM',
      details: `Database restored to snapshot ${backupId}. Pre-restore safety backup: ${safetySnapshot.id}.`,
    });

    return {
      success: true,
      safetyBackupId: safetySnapshot.id,
    };
  }
}

export const dbManager = new DatabaseManager();
