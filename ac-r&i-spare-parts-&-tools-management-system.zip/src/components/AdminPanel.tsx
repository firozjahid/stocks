import React, { useState, useEffect } from 'react';
import {
  Shield,
  Users,
  HardDrive,
  FileSpreadsheet,
  History,
  Settings,
  Plus,
  Edit2,
  Trash2,
  Download,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Upload,
  Search,
  Lock,
  Layers,
  MapPin,
  Clock,
  RefreshCw
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { User, DatabaseBackup, AuditLog, UserRole } from '../types/inventory.js';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';

interface AdminPanelProps {
  initialTab?: string;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ initialTab = 'users' }) => {
  const { user } = useAuth();
  const [tab, setTab] = useState<string>(initialTab);

  // Users tab state
  const [users, setUsers] = useState<User[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // User form
  const [formEmpId, setFormEmpId] = useState('');
  const [formName, setFormName] = useState('');
  const [formDesignation, setFormDesignation] = useState('');
  const [formRole, setFormRole] = useState<UserRole>('OFFICER');
  const [formTeam, setFormTeam] = useState('R&I Cooling Team');
  const [formDept, setFormDept] = useState('AC Research & Innovation');
  const [formPassword, setFormPassword] = useState('');

  // Backups tab state
  const [backups, setBackups] = useState<DatabaseBackup[]>([]);
  const [backupSettings, setBackupSettings] = useState<any>(null);
  const [loadingBackups, setLoadingBackups] = useState(false);
  const [creatingBackup, setCreatingBackup] = useState(false);
  const [restoreConfirmBackup, setRestoreConfirmBackup] = useState<DatabaseBackup | null>(null);
  const [restoring, setRestoring] = useState(false);
  const [clearingDummyData, setClearingDummyData] = useState(false);
  const [clearSuccessMsg, setClearSuccessMsg] = useState<string | null>(null);

  const handleClearDummyData = async () => {
    try {
      setClearingDummyData(true);
      const res = await api.clearAllDummyData();
      setClearSuccessMsg(res.message || 'All dummy data successfully cleared.');
      loadBackups();
    } catch (e: any) {
      console.error(e);
    } finally {
      setClearingDummyData(false);
    }
  };

  // Import tab state
  const [importType, setImportType] = useState<'SPARE_PARTS' | 'TOOLS' | 'USERS'>('SPARE_PARTS');
  const [parsedRows, setParsedRows] = useState<any[]>([]);
  const [importing, setImporting] = useState(false);
  const [importSummary, setImportSummary] = useState<any>(null);
  const [fileName, setFileName] = useState('');

  // Audit Logs state
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [logSearch, setLogSearch] = useState('');
  const [loadingLogs, setLoadingLogs] = useState(false);

  useEffect(() => {
    if (tab === 'users') loadUsers();
    if (tab === 'backup') loadBackups();
    if (tab === 'audit') loadAuditLogs();
  }, [tab]);

  // Loaders
  const loadUsers = async () => {
    try {
      setLoadingUsers(true);
      const res = await api.getUsers();
      setUsers(res.users || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingUsers(false);
    }
  };

  const loadBackups = async () => {
    try {
      setLoadingBackups(true);
      const res = await api.getBackups();
      setBackups(res.backups || []);
      setBackupSettings(res.settings || null);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingBackups(false);
    }
  };

  const loadAuditLogs = async () => {
    try {
      setLoadingLogs(true);
      const res = await api.getAuditLogs({ search: logSearch });
      setLogs(res.logs || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingLogs(false);
    }
  };

  // User Actions
  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingUser) {
        await api.updateUser(editingUser.id, {
          name: formName,
          designation: formDesignation,
          role: formRole,
          team: formTeam,
          department: formDept,
          password: formPassword || undefined,
        });
      } else {
        await api.createUser({
          employeeId: formEmpId,
          name: formName,
          designation: formDesignation,
          role: formRole,
          team: formTeam,
          department: formDept,
          password: formPassword || 'acri123',
        });
      }
      setUserModalOpen(false);
      setEditingUser(null);
      loadUsers();
    } catch (err: any) {
      alert(err?.message || 'Failed to save user.');
    }
  };

  const openAddUser = () => {
    setEditingUser(null);
    setFormEmpId('');
    setFormName('');
    setFormDesignation('Officer');
    setFormRole('OFFICER');
    setFormTeam('R&I Cooling Team');
    setFormDept('AC Research & Innovation');
    setFormPassword('');
    setUserModalOpen(true);
  };

  const openEditUser = (u: User) => {
    setEditingUser(u);
    setFormEmpId(u.employeeId);
    setFormName(u.name);
    setFormDesignation(u.designation);
    setFormRole(u.role);
    setFormTeam(u.team);
    setFormDept(u.department);
    setFormPassword('');
    setUserModalOpen(true);
  };

  const toggleUserStatus = async (u: User) => {
    const nextStatus = u.accountStatus === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    try {
      await api.updateUser(u.id, { accountStatus: nextStatus });
      loadUsers();
    } catch (e: any) {
      alert(e?.message);
    }
  };

  // Backup Actions
  const handleCreateManualBackup = async () => {
    try {
      setCreatingBackup(true);
      await api.createBackup('Manual Super Admin Snapshot');
      loadBackups();
    } catch (err: any) {
      alert(err?.message || 'Failed to trigger backup.');
    } finally {
      setCreatingBackup(false);
    }
  };

  const handleRestore = async (b: DatabaseBackup) => {
    try {
      setRestoring(true);
      const res = await api.restoreBackup(b.id);
      alert(`${res.message}\nSafety Snapshot: ${res.safetyBackupId}`);
      setRestoreConfirmBackup(null);
      loadBackups();
    } catch (err: any) {
      alert(err?.message || 'Restore failed.');
    } finally {
      setRestoring(false);
    }
  };

  // Excel File Parsing with SheetJS (XLSX)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setImportSummary(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws);
        setParsedRows(data);
      } catch (err) {
        alert('Failed to parse Excel file. Please ensure it is a valid .xlsx or .csv.');
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleExecuteImport = async () => {
    if (parsedRows.length === 0) return;
    try {
      setImporting(true);
      const res = await api.importData(importType, parsedRows);
      setImportSummary(res.summary);
      setParsedRows([]);
    } catch (err: any) {
      alert(err?.message || 'Import operation failed.');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50">
      {/* Top Banner */}
      <div className="p-4 sm:p-6 bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
        <div>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-amber-400" />
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight">Super Admin Governance Suite</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Global access control, 5-minute automated backups, Excel master migrations, and immutable audit logs.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex flex-wrap items-center bg-slate-800 p-1 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setTab('users')}
            className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
              tab === 'users' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Users &amp; Roles</span>
          </button>
          <button
            onClick={() => setTab('backup')}
            className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
              tab === 'backup' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>5-Min Backup &amp; Restore</span>
          </button>
          <button
            onClick={() => setTab('import')}
            className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
              tab === 'import' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Excel Migration</span>
          </button>
          <button
            onClick={() => setTab('audit')}
            className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
              tab === 'audit' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Audit Trail</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Users & Roles */}
      {tab === 'users' && (
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Authorized Personnel Database</h2>
              <p className="text-xs text-slate-500">Only authorized employees can access the platform.</p>
            </div>
            <button
              onClick={openAddUser}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add Employee</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px]">
                  <th className="py-3 px-3.5">Employee ID</th>
                  <th className="py-3 px-3.5">Name</th>
                  <th className="py-3 px-3.5">Designation</th>
                  <th className="py-3 px-3.5">Role</th>
                  <th className="py-3 px-3.5">Team</th>
                  <th className="py-3 px-3.5">Status</th>
                  <th className="py-3 px-3.5">Last Login</th>
                  <th className="py-3 px-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3.5 font-mono font-bold text-slate-800">{u.employeeId}</td>
                    <td className="py-2.5 px-3.5 font-semibold text-slate-900">{u.name}</td>
                    <td className="py-2.5 px-3.5 text-slate-600">{u.designation}</td>
                    <td className="py-2.5 px-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        u.role === 'SUPER ADMIN'
                          ? 'bg-amber-100 text-amber-900 border border-amber-300'
                          : u.role === 'HOD' || u.role === 'MODEL MANAGER'
                          ? 'bg-purple-100 text-purple-900'
                          : u.role === 'ENGINEER' || u.role === 'IN-CHARGE'
                          ? 'bg-blue-100 text-blue-900'
                          : 'bg-slate-100 text-slate-800'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5 text-blue-600 font-medium">{u.team}</td>
                    <td className="py-2.5 px-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        u.accountStatus === 'ACTIVE' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {u.accountStatus}
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5 font-mono text-[11px] text-slate-500">{u.lastLogin || 'Never'}</td>
                    <td className="py-2.5 px-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEditUser(u)}
                          className="p-1 text-slate-500 hover:text-blue-600 rounded"
                          title="Edit User"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => toggleUserStatus(u)}
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                            u.accountStatus === 'ACTIVE'
                              ? 'border-rose-200 text-rose-600 hover:bg-rose-50'
                              : 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                          }`}
                        >
                          {u.accountStatus === 'ACTIVE' ? 'Deactivate' : 'Activate'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: 5-Minute Automated Backup & Restore */}
      {tab === 'backup' && (
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Health & Scheduler Status Box */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl border border-emerald-200">
                <Clock className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-slate-900 text-sm">Automated 5-Minute Backup Engine</h3>
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                    Active &amp; Scheduled
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                  Every 5 minutes, an automated snapshot of users, items, requests, movements, and audit logs is preserved.
                </p>
                <div className="flex items-center gap-4 text-xs text-slate-600 font-mono mt-2">
                  <span>Last Successful: <strong>{backupSettings?.lastSuccessfulBackup || 'Just now'}</strong></span>
                  <span>•</span>
                  <span>Interval: <strong>Every 5 mins</strong></span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={loadBackups}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh</span>
              </button>
              <button
                onClick={handleCreateManualBackup}
                disabled={creatingBackup}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition"
              >
                <HardDrive className="w-4 h-4" />
                <span>{creatingBackup ? 'Creating Snapshot...' : 'Create Snapshot Now'}</span>
              </button>
              <button
                onClick={handleClearDummyData}
                disabled={clearingDummyData}
                className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                title="Wipes dummy spare parts and mock transactions"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                <span>{clearingDummyData ? 'Clearing...' : 'Clear All Dummy Data'}</span>
              </button>
            </div>
          </div>

          {clearSuccessMsg && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{clearSuccessMsg}</span>
              </div>
              <button onClick={() => setClearSuccessMsg(null)} className="text-emerald-700 font-bold text-xs hover:underline">Dismiss</button>
            </div>
          )}

          {/* Backup Snapshots Catalog */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Database Snapshot Catalog ({backups.length} Snapshots)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Pre-restore safety backups are created automatically prior to any restoration.
                </p>
              </div>
            </div>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px]">
                  <th className="py-2.5 px-3.5">Backup ID</th>
                  <th className="py-2.5 px-3.5">Date &amp; Time</th>
                  <th className="py-2.5 px-3.5">Size</th>
                  <th className="py-2.5 px-3.5">Created By</th>
                  <th className="py-2.5 px-3.5">Contents Summary</th>
                  <th className="py-2.5 px-3.5">Status</th>
                  <th className="py-2.5 px-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {backups.map(b => (
                  <tr key={b.id} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3.5 font-mono font-bold text-slate-800">{b.id}</td>
                    <td className="py-2.5 px-3.5 font-mono text-[11px] text-slate-600">
                      {b.date} {b.time}
                    </td>
                    <td className="py-2.5 px-3.5 font-mono text-slate-600">
                      {(b.sizeBytes / 1024).toFixed(1)} KB
                    </td>
                    <td className="py-2.5 px-3.5 text-slate-700 font-medium">{b.createdBy}</td>
                    <td className="py-2.5 px-3.5 text-slate-500 text-[11px]">
                      {b.recordCounts ? (
                        <span>
                          {b.recordCounts.items} items • {b.recordCounts.users} users • {b.recordCounts.transactions} trns
                        </span>
                      ) : (
                        b.description || 'System snapshot'
                      )}
                    </td>
                    <td className="py-2.5 px-3.5">
                      <span className="bg-emerald-100 text-emerald-800 text-[9px] font-bold px-1.5 py-0.5 rounded">
                        {b.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <a
                          href={`/api/backups/${b.filename}/download`}
                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-semibold flex items-center gap-1"
                        >
                          <Download className="w-3 h-3 text-blue-600" />
                          <span>Download</span>
                        </a>
                        <button
                          onClick={() => setRestoreConfirmBackup(b)}
                          className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded text-[11px] font-semibold flex items-center gap-1 shadow-xs"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Restore</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Excel Migration & Import */}
      {tab === 'import' && (
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Excel / Google Sheet Master Data Migration
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Upload your existing Excel (.xlsx) or CSV spreadsheet to migrate users, spare parts, or tools into the database.
              </p>
            </div>

            {/* Import Type Switcher */}
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold text-slate-700">Target Module:</span>
              <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs font-medium">
                <button
                  onClick={() => setImportType('SPARE_PARTS')}
                  className={`px-3 py-1 rounded-md transition ${
                    importType === 'SPARE_PARTS' ? 'bg-white text-emerald-800 font-bold shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Spare Parts
                </button>
                <button
                  onClick={() => setImportType('TOOLS')}
                  className={`px-3 py-1 rounded-md transition ${
                    importType === 'TOOLS' ? 'bg-white text-blue-800 font-bold shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Tools &amp; Equipment
                </button>
                <button
                  onClick={() => setImportType('USERS')}
                  className={`px-3 py-1 rounded-md transition ${
                    importType === 'USERS' ? 'bg-white text-indigo-800 font-bold shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Users / Employees
                </button>
              </div>
            </div>

            {/* File Upload Dropzone */}
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center bg-slate-50/50 hover:bg-slate-50 transition relative">
              <Upload className="w-10 h-10 text-slate-400 mx-auto mb-2" />
              <div className="text-sm font-semibold text-slate-700">
                {fileName ? fileName : 'Select or drop Excel (.xlsx, .xls, .csv) file'}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Automatic column matching for Item Code, Name, Quantity, Rack, Shelf, Owner, etc.
              </p>
              <input
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={handleFileUpload}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </div>

            {/* Parsed Preview Table */}
            {parsedRows.length > 0 && (
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-slate-800">
                    Previewing {parsedRows.length} Rows from spreadsheet
                  </div>
                  <button
                    onClick={handleExecuteImport}
                    disabled={importing}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition"
                  >
                    {importing ? 'Importing Data...' : `Execute Migration (${parsedRows.length} Records)`}
                  </button>
                </div>

                <div className="border border-slate-200 rounded-xl overflow-x-auto max-h-64 shadow-xs">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-100 text-slate-600 text-[11px] sticky top-0">
                      <tr>
                        {Object.keys(parsedRows[0] || {}).slice(0, 8).map(k => (
                          <th key={k} className="p-2 border-b border-slate-200">{k}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {parsedRows.slice(0, 10).map((r, i) => (
                        <tr key={i}>
                          {Object.values(r).slice(0, 8).map((val: any, vi) => (
                            <td key={vi} className="p-2 text-slate-700 max-w-[150px] truncate">
                              {String(val)}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Import Summary Results */}
            {importSummary && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 text-xs">
                <div className="font-bold text-emerald-900 text-sm flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Migration Execution Completed</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono">
                  <div className="bg-white p-2 rounded border border-emerald-200">
                    <span className="text-[10px] text-slate-500 block">IMPORTED</span>
                    <strong className="text-emerald-700 text-sm">{importSummary.imported}</strong>
                  </div>
                  <div className="bg-white p-2 rounded border border-emerald-200">
                    <span className="text-[10px] text-slate-500 block">UPDATED</span>
                    <strong className="text-blue-700 text-sm">{importSummary.updated}</strong>
                  </div>
                  <div className="bg-white p-2 rounded border border-emerald-200">
                    <span className="text-[10px] text-slate-500 block">FAILED</span>
                    <strong className="text-rose-700 text-sm">{importSummary.failed}</strong>
                  </div>
                  <div className="bg-white p-2 rounded border border-emerald-200">
                    <span className="text-[10px] text-slate-500 block">TOTAL</span>
                    <strong className="text-slate-800 text-sm">{importSummary.total}</strong>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 4: Permanent Audit Logs */}
      {tab === 'audit' && (
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900">System Audit Trail &amp; Compliance</h2>
              <p className="text-xs text-slate-500">Immutable permanent activity log of every operation.</p>
            </div>
            <div className="relative min-w-[260px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={logSearch}
                onChange={e => setLogSearch(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && loadAuditLogs()}
                placeholder="Search user, action, record ID..."
                className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px]">
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">User &amp; ID</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">Module</th>
                  <th className="py-2.5 px-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                {logs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 text-slate-500">{log.timestamp}</td>
                    <td className="py-2 px-3 font-semibold text-slate-800">
                      {log.user} (#{log.employeeId})
                    </td>
                    <td className="py-2 px-3">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        log.action === 'CREATE' ? 'bg-emerald-100 text-emerald-800' :
                        log.action === 'DELETE' ? 'bg-rose-100 text-rose-800' :
                        log.action === 'APPROVE' ? 'bg-blue-100 text-blue-800' :
                        log.action === 'RESTORE' ? 'bg-purple-100 text-purple-800' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-slate-600">{log.module}</td>
                    <td className="py-2 px-3 font-sans text-slate-700 max-w-md truncate" title={log.details}>
                      {log.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* User Add / Edit Modal */}
      {userModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              {editingUser ? `Edit Employee: ${editingUser.name}` : 'Add New AC R&I Employee'}
            </h3>

            <form onSubmit={handleSaveUser} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Employee ID</label>
                <input
                  type="text"
                  required
                  disabled={!!editingUser}
                  value={formEmpId}
                  onChange={e => setFormEmpId(e.target.value)}
                  placeholder="e.g. 38250"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="e.g. Jahid Hasan"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Designation</label>
                <input
                  type="text"
                  required
                  value={formDesignation}
                  onChange={e => setFormDesignation(e.target.value)}
                  placeholder="e.g. Senior Lead Engineer"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Role</label>
                  <select
                    value={formRole}
                    onChange={e => setFormRole(e.target.value as UserRole)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-800"
                  >
                    <option value="SUPER ADMIN">SUPER ADMIN</option>
                    <option value="HOD">HOD</option>
                    <option value="MODEL MANAGER">MODEL MANAGER</option>
                    <option value="IN-CHARGE">IN-CHARGE</option>
                    <option value="ENGINEER">ENGINEER</option>
                    <option value="OFFICER">OFFICER</option>
                    <option value="TECHNICIAN">TECHNICIAN</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Team</label>
                  <input
                    type="text"
                    required
                    value={formTeam}
                    onChange={e => setFormTeam(e.target.value)}
                    placeholder="e.g. R&I Cooling Team"
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Password</label>
                <input
                  type="password"
                  value={formPassword}
                  onChange={e => setFormPassword(e.target.value)}
                  placeholder={editingUser ? 'Leave blank to preserve current' : 'Initial login password'}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setUserModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs"
                >
                  Save Employee
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Mandatory Safety Confirmation Modal Before Restore */}
      {restoreConfirmBackup && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 text-amber-600">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              <span>Safety Snapshot &amp; Database Restoration</span>
            </h3>

            <p className="text-xs text-slate-700 leading-relaxed">
              This operation will restore the selected database snapshot: <strong className="font-mono">{restoreConfirmBackup.id}</strong> ({restoreConfirmBackup.date} {restoreConfirmBackup.time}).
            </p>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Mandatory Safety Backup Enforced</span>
              </div>
              <p>
                A complete safety snapshot of the live database will be created automatically immediately before restoration occurs. Nothing will be silently lost.
              </p>
            </div>

            <div className="pt-3 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setRestoreConfirmBackup(null)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={restoring}
                onClick={() => handleRestore(restoreConfirmBackup)}
                className="px-5 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-xs transition"
              >
                {restoring ? 'Creating Safety Snapshot & Restoring...' : 'Confirm Safe Restore'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
