import React from 'react';
import {
  LayoutDashboard,
  Box,
  Wrench,
  Package,
  Layers,
  Search,
  Inbox,
  Send,
  History,
  ArrowRightLeft,
  RotateCcw,
  FileText,
  Shield,
  Users,
  HardDrive,
  FileSpreadsheet,
  FileCheck,
  Settings,
  UserCheck,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';

interface SidebarProps {
  currentView: string;
  currentFilter?: any;
  onNavigate: (view: string, filter?: any) => void;
  incomingPendingCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  currentFilter,
  onNavigate,
  incomingPendingCount,
}) => {
  const { user, isSuperAdmin } = useAuth();

  const isNavActive = (view: string, filterKey?: string, filterVal?: string) => {
    if (currentView !== view) return false;
    if (!filterKey) return true;
    return currentFilter && currentFilter[filterKey] === filterVal;
  };

  const navClass = (view: string, filterKey?: string, filterVal?: string) => {
    const active = isNavActive(view, filterKey, filterVal);
    return `w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition group ${
      active
        ? 'bg-blue-600 text-white font-semibold shadow-sm'
        : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
    }`;
  };

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col shrink-0 overflow-y-auto select-none">
      <div className="p-3 space-y-6 flex-1">
        {/* Main Dashboard */}
        <div>
          <button
            onClick={() => onNavigate('dashboard')}
            className={navClass('dashboard')}
          >
            <div className="flex items-center gap-2.5">
              <LayoutDashboard className="w-4 h-4" />
              <span>Executive Dashboard</span>
            </div>
          </button>
        </div>

        {/* MY INVENTORY */}
        <div>
          <div className="px-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            My Inventory
          </div>
          <div className="space-y-0.5">
            <button
              onClick={() => onNavigate('inventory', { scope: 'my', type: 'SPARE_PART' })}
              className={navClass('inventory', 'scope', 'my')}
            >
              <div className="flex items-center gap-2.5">
                <Box className="w-4 h-4 text-emerald-400" />
                <span>My Spare Parts</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('inventory', { scope: 'my', type: 'TOOL_EQUIPMENT' })}
              className={navClass('inventory', 'scope', 'my_tools')}
            >
              <div className="flex items-center gap-2.5">
                <Wrench className="w-4 h-4 text-blue-400" />
                <span>My Tools &amp; Gear</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('inventory', { scope: 'own_team' })}
              className={navClass('inventory', 'scope', 'own_team')}
            >
              <div className="flex items-center gap-2.5">
                <Layers className="w-4 h-4 text-indigo-400" />
                <span>Own Team Items</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('inventory', { scope: 'other_team' })}
              className={navClass('inventory', 'scope', 'other_team')}
            >
              <div className="flex items-center gap-2.5">
                <ArrowRightLeft className="w-4 h-4 text-amber-400" />
                <span>Other Team Items (Borrowed)</span>
              </div>
            </button>
          </div>
        </div>

        {/* GENERAL INVENTORY CATALOG */}
        <div>
          <div className="px-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            General Inventory
          </div>
          <div className="space-y-0.5">
            <button
              onClick={() => onNavigate('inventory', { type: 'SPARE_PART' })}
              className={navClass('inventory', 'type', 'SPARE_PART')}
            >
              <div className="flex items-center gap-2.5">
                <Package className="w-4 h-4 text-slate-400" />
                <span>Spare Parts</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('inventory', { type: 'TOOL_EQUIPMENT' })}
              className={navClass('inventory', 'type', 'TOOL_EQUIPMENT')}
            >
              <div className="flex items-center gap-2.5">
                <Wrench className="w-4 h-4 text-slate-400" />
                <span>Tools &amp; Equipment</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('inventory', {})}
              className={navClass('inventory')}
            >
              <div className="flex items-center gap-2.5">
                <Layers className="w-4 h-4 text-slate-400" />
                <span>All Catalog Items</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('search')}
              className={navClass('search')}
            >
              <div className="flex items-center gap-2.5">
                <Search className="w-4 h-4 text-slate-400" />
                <span>Advanced Search Engine</span>
              </div>
            </button>
          </div>
        </div>

        {/* REQUESTS & APPROVAL WORKFLOW */}
        <div>
          <div className="px-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Requests &amp; Approvals
          </div>
          <div className="space-y-0.5">
            <button
              onClick={() => onNavigate('requests', { tab: 'incoming' })}
              className={navClass('requests', 'tab', 'incoming')}
            >
              <div className="flex items-center gap-2.5">
                <Inbox className="w-4 h-4 text-amber-400" />
                <span>Incoming Requests</span>
              </div>
              {incomingPendingCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 animate-pulse">
                  {incomingPendingCount}
                </span>
              )}
            </button>

            <button
              onClick={() => onNavigate('requests', { tab: 'my' })}
              className={navClass('requests', 'tab', 'my')}
            >
              <div className="flex items-center gap-2.5">
                <Send className="w-4 h-4 text-blue-400" />
                <span>My Outgoing Requests</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('requests', { tab: 'history' })}
              className={navClass('requests', 'tab', 'history')}
            >
              <div className="flex items-center gap-2.5">
                <History className="w-4 h-4 text-slate-400" />
                <span>Request History</span>
              </div>
            </button>
          </div>
        </div>

        {/* TRANSACTIONS LEDGER */}
        <div>
          <div className="px-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Movement &amp; History
          </div>
          <div className="space-y-0.5">
            <button
              onClick={() => onNavigate('transactions', { type: 'BORROW' })}
              className={navClass('transactions', 'type', 'BORROW')}
            >
              <div className="flex items-center gap-2.5">
                <ArrowRightLeft className="w-4 h-4 text-blue-400" />
                <span>Borrowed Items</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('transactions', { type: 'RETURN' })}
              className={navClass('transactions', 'type', 'RETURN')}
            >
              <div className="flex items-center gap-2.5">
                <RotateCcw className="w-4 h-4 text-emerald-400" />
                <span>Returned Items</span>
              </div>
            </button>

            <button
              onClick={() => onNavigate('transactions', {})}
              className={navClass('transactions')}
            >
              <div className="flex items-center gap-2.5">
                <FileText className="w-4 h-4 text-slate-400" />
                <span>All Transactions</span>
              </div>
            </button>
          </div>
        </div>

        {/* REPORTS */}
        <div>
          <div className="px-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Reports &amp; Analytics
          </div>
          <div className="space-y-0.5">
            <button
              onClick={() => onNavigate('reports')}
              className={navClass('reports')}
            >
              <div className="flex items-center gap-2.5">
                <FileCheck className="w-4 h-4 text-slate-400" />
                <span>Inventory &amp; Audit Reports</span>
              </div>
            </button>
          </div>
        </div>

        {/* SUPER ADMIN PANEL (SUPER ADMIN ONLY) */}
        {isSuperAdmin && (
          <div className="pt-2 border-t border-slate-800/80">
            <div className="px-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span>Super Admin Suite</span>
            </div>
            <div className="space-y-0.5">
              <button
                onClick={() => onNavigate('admin', { tab: 'users' })}
                className={navClass('admin', 'tab', 'users')}
              >
                <div className="flex items-center gap-2.5">
                  <Users className="w-4 h-4 text-slate-400" />
                  <span>Users &amp; Roles</span>
                </div>
              </button>

              <button
                onClick={() => onNavigate('admin', { tab: 'backup' })}
                className={navClass('admin', 'tab', 'backup')}
              >
                <div className="flex items-center gap-2.5">
                  <HardDrive className="w-4 h-4 text-emerald-400" />
                  <span>5-Min Backup &amp; Restore</span>
                </div>
              </button>

              <button
                onClick={() => onNavigate('admin', { tab: 'import' })}
                className={navClass('admin', 'tab', 'import')}
              >
                <div className="flex items-center gap-2.5">
                  <FileSpreadsheet className="w-4 h-4 text-blue-400" />
                  <span>Excel Migration &amp; Import</span>
                </div>
              </button>

              <button
                onClick={() => onNavigate('admin', { tab: 'audit' })}
                className={navClass('admin', 'tab', 'audit')}
              >
                <div className="flex items-center gap-2.5">
                  <History className="w-4 h-4 text-purple-400" />
                  <span>Audit Logs</span>
                </div>
              </button>

              <button
                onClick={() => onNavigate('admin', { tab: 'locations' })}
                className={navClass('admin', 'tab', 'locations')}
              >
                <div className="flex items-center gap-2.5">
                  <Settings className="w-4 h-4 text-slate-400" />
                  <span>Locations &amp; Teams</span>
                </div>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="p-3 bg-slate-900/60 border-t border-slate-800 text-[11px] text-slate-400 space-y-1.5">
        <div className="flex items-center justify-between">
          <div className="truncate">
            <span className="text-slate-300 font-medium">Logged:</span> {user?.name?.split(' ')[0]}
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/40">
            Online
          </span>
        </div>
        <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-1.5 text-center font-mono text-cyan-400/80">
          Software Development By Jahid AC R&amp;I (38250)
        </div>
      </div>
    </aside>
  );
};
