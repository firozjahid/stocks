import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { Navbar } from './components/Navbar.js';
import { Sidebar } from './components/Sidebar.js';
import { DashboardView } from './components/DashboardView.js';
import { InventoryView } from './components/InventoryView.js';
import { RequestsView } from './components/RequestsView.js';
import { TransactionsView } from './components/TransactionsView.js';
import { ReportsView } from './components/ReportsView.js';
import { AdminPanel } from './components/AdminPanel.js';
import { ProfileView } from './components/ProfileView.js';
import { LoginView } from './components/LoginView.js';
import { ItemDetailsModal } from './components/ItemDetailsModal.js';
import { ItemFormModal } from './components/ItemFormModal.js';
import { RequestItemModal } from './components/RequestItemModal.js';
import { ReturnModal } from './components/ReturnModal.js';
import { GlobalSearchModal } from './components/GlobalSearchModal.js';
import { InventoryItem } from './types/inventory.js';
import { api } from './services/api.js';

function AppContent() {
  const { user, loading } = useAuth();

  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [currentFilter, setCurrentFilter] = useState<any>({});
  const [incomingPendingCount, setIncomingPendingCount] = useState<number>(0);

  // Modals
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [requestModalItem, setRequestModalItem] = useState<InventoryItem | null>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [createModalType, setCreateModalType] = useState<'SPARE_PART' | 'TOOL_EQUIPMENT'>('SPARE_PART');
  const [editItem, setEditItem] = useState<InventoryItem | null>(null);
  const [returnItem, setReturnItem] = useState<InventoryItem | null>(null);
  const [searchModalOpen, setSearchModalOpen] = useState(false);

  // Refresh pending requests badge count periodically
  const fetchPendingCounts = async () => {
    if (!user) return;
    try {
      const res = await api.getRequests('incoming');
      const count = (res.requests || []).filter(r => r.status === 'PENDING').length;
      setIncomingPendingCount(count);
    } catch (e) {
      // Ignore
    }
  };

  useEffect(() => {
    fetchPendingCounts();
    const interval = setInterval(fetchPendingCounts, 20000);
    return () => clearInterval(interval);
  }, [user]);

  // Global Ctrl+K / Cmd+K listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchModalOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleNavigate = (view: string, filter: any = {}) => {
    setCurrentView(view);
    setCurrentFilter(filter);
  };

  const handleSelectItem = (item: InventoryItem) => {
    setSelectedItem(item);
  };

  const handleOpenRequest = (item: InventoryItem) => {
    setRequestModalItem(item);
  };

  const handleOpenCreate = (type: 'SPARE_PART' | 'TOOL_EQUIPMENT') => {
    setCreateModalType(type);
    setEditItem(null);
    setCreateModalOpen(true);
  };

  const handleOpenEdit = (item: InventoryItem) => {
    setEditItem(item);
    setCreateModalType(item.type);
    setCreateModalOpen(true);
  };

  const handleOpenReturn = (item: InventoryItem) => {
    setReturnItem(item);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white text-sm">
        <div className="flex items-center gap-2.5">
          <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <span>Starting AC R&amp;I Management System...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginView />;
  }

  return (
    <div className="h-screen flex flex-col bg-slate-100 overflow-hidden font-sans">
      {/* Top Enterprise Header */}
      <Navbar
        onOpenSearch={() => setSearchModalOpen(true)}
        onNavigate={handleNavigate}
      />

      {/* Main App Workspace */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          currentView={currentView}
          currentFilter={currentFilter}
          onNavigate={handleNavigate}
          incomingPendingCount={incomingPendingCount}
        />

        {/* View Switcher Content */}
        <main className="flex-1 flex flex-col overflow-hidden bg-slate-50">
          {currentView === 'dashboard' && (
            <DashboardView
              onNavigate={handleNavigate}
              onOpenCreate={handleOpenCreate}
              onSelectItem={handleSelectItem}
            />
          )}

          {currentView === 'inventory' && (
            <InventoryView
              initialFilter={currentFilter}
              onSelectItem={handleSelectItem}
              onRequestItem={handleOpenRequest}
              onOpenCreate={handleOpenCreate}
              onOpenEdit={handleOpenEdit}
              onOpenReturn={handleOpenReturn}
            />
          )}

          {currentView === 'search' && (
            <InventoryView
              initialFilter={{}}
              onSelectItem={handleSelectItem}
              onRequestItem={handleOpenRequest}
              onOpenCreate={handleOpenCreate}
              onOpenEdit={handleOpenEdit}
              onOpenReturn={handleOpenReturn}
            />
          )}

          {currentView === 'requests' && (
            <RequestsView initialTab={currentFilter?.tab || 'incoming'} />
          )}

          {currentView === 'transactions' && (
            <TransactionsView initialFilter={currentFilter} />
          )}

          {currentView === 'reports' && <ReportsView />}

          {currentView === 'admin' && (
            <AdminPanel initialTab={currentFilter?.tab || 'users'} />
          )}

          {currentView === 'profile' && <ProfileView />}
        </main>
      </div>

      {/* Modals */}
      {selectedItem && (
        <ItemDetailsModal
          item={selectedItem}
          onClose={() => setSelectedItem(null)}
          onRequestItem={handleOpenRequest}
          onOpenReturn={handleOpenReturn}
        />
      )}

      {requestModalItem && (
        <RequestItemModal
          item={requestModalItem}
          onClose={() => setRequestModalItem(null)}
          onRequestSubmitted={() => {
            fetchPendingCounts();
            handleNavigate('requests', { tab: 'my' });
          }}
        />
      )}

      {createModalOpen && (
        <ItemFormModal
          initialType={createModalType}
          editItem={editItem}
          onClose={() => {
            setCreateModalOpen(false);
            setEditItem(null);
          }}
          onSaved={() => {
            // Trigger inventory refresh by re-navigating
            handleNavigate('inventory', currentFilter);
          }}
        />
      )}

      {returnItem && (
        <ReturnModal
          item={returnItem}
          mode="INITIATE_RETURN"
          onClose={() => setReturnItem(null)}
          onCompleted={() => {
            handleNavigate('requests', { tab: 'my' });
          }}
        />
      )}

      {searchModalOpen && (
        <GlobalSearchModal
          onClose={() => setSearchModalOpen(false)}
          onSelectItem={handleSelectItem}
          onRequestItem={handleOpenRequest}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
