import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, InventoryItem, ItemRequest, UserRole } from '../types/inventory.js';
import { api } from '../services/api.js';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (employeeId: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  switchUser: (employeeId: string) => Promise<void>;
  canManageInventory: boolean;
  isSuperAdmin: boolean;
  isOwner: (item: InventoryItem) => boolean;
  canEditItem: (item: InventoryItem) => boolean;
  canDeleteItem: (item: InventoryItem) => boolean;
  canApproveRequest: (request: ItemRequest) => boolean;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchCurrentUser = async () => {
    try {
      setLoading(true);
      const res = await api.getCurrentUser();
      setUser(res.user);
    } catch (err) {
      console.warn('No active session, fallback to default initial login');
      // If default employee id failed, attempt login as Jahid Hasan with password = ID
      try {
        const loginRes = await api.login('38250', '38250');
        setUser(loginRes.user);
      } catch (e) {
        setUser(null);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCurrentUser();
  }, []);

  const login = async (employeeId: string, password: string) => {
    const res = await api.login(employeeId, password);
    setUser(res.user);
  };

  const logout = async () => {
    await api.logout();
    setUser(null);
  };

  const switchUser = async (employeeId: string) => {
    api.setEmployeeId(employeeId);
    try {
      const res = await api.getCurrentUser();
      setUser(res.user);
    } catch (e) {
      console.error('Failed to switch user:', e);
    }
  };

  // CBO, DCBO, and SUPER ADMIN have full top executive and governance authority
  const isSuperAdmin = user?.role === 'SUPER ADMIN' || user?.role === 'CBO' || user?.role === 'DCBO';

  // Role permissions: Only Officer role can entry/add Spare Parts and Tools
  const canManageInventory = !!(user && (user.role === 'OFFICER' || user.role === 'SUPER ADMIN'));

  const isOwner = (item: InventoryItem) => {
    if (!user) return false;
    return item.responsibleEmployeeId === user.employeeId;
  };

  const canEditItem = (item: InventoryItem) => {
    if (!user) return false;
    if (user.role === 'SUPER ADMIN') return true;
    return user.role === 'OFFICER' && item.responsibleEmployeeId === user.employeeId;
  };

  const canDeleteItem = (item: InventoryItem) => {
    if (!user) return false;
    if (user.role === 'SUPER ADMIN') return true;
    return user.role === 'OFFICER' && item.responsibleEmployeeId === user.employeeId;
  };

  const canApproveRequest = (request: ItemRequest) => {
    if (!user) return false;
    if (isSuperAdmin) return true;
    return request.ownerEmployeeId === user.employeeId;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        logout,
        switchUser,
        canManageInventory,
        isSuperAdmin,
        isOwner,
        canEditItem,
        canDeleteItem,
        canApproveRequest,
        refreshUser: fetchCurrentUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
